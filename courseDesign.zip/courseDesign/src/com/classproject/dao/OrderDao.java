package com.classproject.dao;

import java.util.List;

import com.classproject.domain.Order;

public interface OrderDao {

	List<Order> getorder();

	void clean();
	
	/**
	 * 查看订单是否存在
	 * @return
	 */
	boolean checkIfOrder();
	
	/**
	 * 删除指定订单
	 * @param orderId
	 * @return
	 */
	void deleteOrderToOrders(int orderId);

}
