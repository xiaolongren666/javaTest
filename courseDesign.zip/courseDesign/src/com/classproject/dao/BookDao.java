package com.classproject.dao;

import java.util.List;

import com.classproject.domain.Book;

public interface BookDao {

	// 获得书库中所有的书籍，返回一个书的集合
	List<Book> list();

	// 条件检索书籍，返回一个书的集合
	List<Book> SerachBookByCondition(String author, String title, String name, String price1, String price2);

	/**
	 * 根据图书号删除图书
	 * @param bookId
	 */
	void deleteBook(Integer bookId);
}
