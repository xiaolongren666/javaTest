package com.classproject.dao;

import java.util.List;

import com.classproject.domain.ShopHistory;

public interface ShopHistoryDao {

	void insert(ShopHistory shophistory);

	/**
	 * 根据用户id
	 * @param userId
	 * @return
	 */
	List<ShopHistory> getShopHistory(Integer userId);
	
}
