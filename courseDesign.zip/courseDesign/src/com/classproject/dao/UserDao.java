package com.classproject.dao;

import java.util.Date;

import com.classproject.domain.User;

public interface UserDao {

	// 用户注册
	long insertUser(User user);

	// 根据用户id创建购物车 和个人账户
	void creatShopCart(int userId);

	// 根据用户id创建个人账户
	void createUserAcount(int userId, float blance);

	// 用户登录
	Integer login(User user);
	
	// 根据用户的id查询用户的个人信息
	Integer selectUserInfor(int userId);
	
	/**
	 * 根据用户id获取用户注册时间
	 * @param userId
	 * @return
	 */
	Date getRegisterTime(int userId);
	
	/**
	 * 根据用户id获取权限
	 * @param userId
	 * @return
	 */
	long getRoleld(Integer userId);
}
