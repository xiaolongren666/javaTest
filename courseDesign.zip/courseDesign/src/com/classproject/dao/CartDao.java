package com.classproject.dao;

import java.util.List;

import com.classproject.domain.Book;
import com.classproject.domain.Cart;
import com.classproject.domain.Order;

public interface CartDao {

	// 根据用户id查找购物车id
	Integer GetUserCartId(int userId);
	
	long GetUserShopCout(int cartId);

	// 根据用户id查询用户购物车中的条目
	List<Cart> carts(int userId);

	// 根据书名，返回书号、书题和书价
	List<Book> GetBookTitleAndPrice(String bookName);

	// 根据用户选择的书籍id去查找该用户的购物车中是否存在该商品
	Integer ifHaveThisBook(int userId, int bookId);

	// 根据用户的id和选择的书籍id和用户的购物车id检索出该商品在此用户购物车中的数目，返回count
	Integer SelectThisBookCount(int userId, int bookId);
	// 根据用户的id和选择的书籍id和用户的购物车id检索出该商品在此用户购物车中的数目，返回count
		Integer SelectThisBookPrice(int userId, int bookId);
	// 若存在该书籍，执行更新操作
	// 并且在我的购物车页面可以修改书籍数量
	void UpdateThisBookCount(int count, int bookId, int cartId);
	// 若不存在该书籍，执行插入操作
	void InsertBookToCart(int cartId, int bookId, String bookName, String bookTitle, float bookPrice, int count);

	// 点击删除按钮，执行在购物车中删除的操作
	void DeleteBookToCart(int cartId, int bookId);

	// 点击创建订单按钮，将购物信息添加到临时表订单表中
	void addThisBookToOrder(String userName, int bookId, String bookName, float bookPrice, int bookCount);

	// 查询该用户一共有多少笔订单
	long selectUserOrders(String userName);

	// 根据用户订单来计算出订单总金额
	Double GetTotalAmount(String userName);

	// 订单列表的查询操作
	List<Order> orders(String userName);

}
