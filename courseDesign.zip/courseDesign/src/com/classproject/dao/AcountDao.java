package com.classproject.dao;

import java.util.List;

import com.classproject.domain.Acount;

public interface AcountDao {

	// 根据用户id查询账户id
	int getUserAcountId(int userId);

	// 显示个人账户余额
	List<Acount> acounts(int acountId, int userId);

	// 进行账户充值
	void AcountRecharge(float finalAmount, int acountId, int userId);

	Acount getUserAcountById(Integer userId);

	void updateBlance(Acount acount);
	
}
