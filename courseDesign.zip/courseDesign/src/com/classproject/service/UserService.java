package com.classproject.service;

import java.util.Date;

import com.classproject.DaoImpl.UserDaoImpl;
import com.classproject.dao.UserDao;
import com.classproject.domain.User;

public class UserService {

	UserDao userDao = new UserDaoImpl();

	// 登录验证
	public Integer login(User user) {
		Integer login = userDao.login(user);
		return login;
	}
	
	/**
	 * 根据用户id获取权限
	 * @param userId
	 * @return
	 */
	public long getRoleld(Integer userId) {
		long roleld = userDao.getRoleld(userId);
		return roleld;
	} 

	// 用户成功注册后录入信息
	// 并创建唯一的购物车
	// 并创建唯一的用户帐户
	public void insertUser(User user, float blance) {
		int userId = (int) userDao.insertUser(user);
		userDao.creatShopCart(userId);
		userDao.createUserAcount(userId, blance);
	}
	//根据用户的id查询用户的个人信息
	public Integer selectUserInfor(int userId){
		Integer UserInfo=userDao.selectUserInfor(userId);
		return UserInfo;
	}
	
	/**
	 * 根据用户id获取注册时间
	 * @param userId
	 * @return
	 */
	public Date getRegisterTime(int userId){
		Date registerTime = userDao.getRegisterTime(userId);
		return registerTime;
	}
}
