package com.classproject.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.classproject.DaoImpl.AcountDaoImpl;
import com.classproject.DaoImpl.OrderDaoImpl;
import com.classproject.DaoImpl.ShopHistoryDaoImpl;
import com.classproject.dao.AcountDao;
import com.classproject.dao.OrderDao;
import com.classproject.dao.ShopHistoryDao;
import com.classproject.domain.Acount;
import com.classproject.domain.Order;
import com.classproject.domain.ShopHistory;

public class AcountService {
	AcountDao acountDao = new AcountDaoImpl();

	// 根据用户id获得账户id
	public int getUserAcountId(int userId) {
		int userAcountId = acountDao.getUserAcountId(userId);
		return userAcountId;
	}

	// 获取账户余额，显示到前端页面
	public List<Acount> acounts(int acountId, int userId) {
		List<Acount> acounts = acountDao.acounts(acountId, userId);
		return acounts;
	}

	// 账户充值操作
	public void AcountRecharge(float finalAmount, int acountId, int userId) {
		acountDao.AcountRecharge(finalAmount, acountId, userId);
	}

	ShopHistoryDao shophistoryDao = new ShopHistoryDaoImpl();
	OrderDao orderDao = new OrderDaoImpl();

	public int totalAmount(Integer userId, Float float1, String username) {
		Acount acount = acountDao.getUserAcountById(userId);
		float difference = acount.getBlance() - float1;
		
		if (difference<0) {
			return 0;
		}else{
			
			acount.setBlance(acount.getBlance() - float1);
			acountDao.updateBlance(acount);
			
			ShopHistory shophistory = new ShopHistory();
			List<Order> orderList = orderDao.getorder();
			for (Order order : orderList) {
				shophistory.setShopTime(new Date(new java.util.Date().getTime()));
				shophistory.setDescription(order.getBookName());
				shophistory.setUserId(userId);
				shophistory.setUserName(username);
				shophistoryDao.insert(shophistory);
			}
			orderDao.clean();
		}

		return 1;
	}
}
