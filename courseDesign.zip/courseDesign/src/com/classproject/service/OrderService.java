/**
 * 
 */
package com.classproject.service;

import java.util.List;

import com.classproject.DaoImpl.OrderDaoImpl;
import com.classproject.dao.OrderDao;
import com.classproject.domain.Order;

/*
*@Author:小龙人
*@File Name:OrderService.java
*@Created Time:上午11:10:22
*@Introduce Function:TODO
*/
public class OrderService {
	OrderDao orderDao = new OrderDaoImpl();
	
	public List<Order> getOrder() {
		return orderDao.getorder();
	}
	
	/**
	 * 检查订单是否存在
	 * @return
	 */
	public boolean checkIfOrder() {
		boolean ifOrders = orderDao.checkIfOrder();
		return ifOrders;
	}
	
	/**
	 * 删除指定的
	 * @param orderId
	 */
	public void deleteOrderToOrders(int orderId) {
		orderDao.deleteOrderToOrders(orderId);
	}
}
