package com.classproject.service;

import java.util.List;

import com.classproject.DaoImpl.BookDaoImpl;
import com.classproject.dao.BookDao;
import com.classproject.domain.Book;

public class BookService {

	BookDao bookDao = new BookDaoImpl();

	// 获得书库中所有的书籍
	public List<Book> list() {
		List<Book> list = bookDao.list();
		return list;
	}

	// 条件检索书籍
	public List<Book> SerachBookByCondition(String author, String title, String name, String price1, String price2) {
		List<Book> list = bookDao.SerachBookByCondition(author, title, name, price1, price2);
		return list;
	}
	
	public void deleteBook(Integer bookId) {
		bookDao.deleteBook(bookId);
	}

}
