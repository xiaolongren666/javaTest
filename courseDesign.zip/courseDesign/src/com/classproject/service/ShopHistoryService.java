/**
 * 
 */
package com.classproject.service;

import java.util.List;

import com.classproject.DaoImpl.ShopHistoryDaoImpl;
import com.classproject.dao.ShopHistoryDao;
import com.classproject.domain.ShopHistory;

/*
*@Author:小龙人
*@File Name:ShopHistoryService.java
*@Created Time:下午8:06:01
*@Introduce Function:TODO
*/
public class ShopHistoryService {
	ShopHistoryDao shopHistoryDao = new ShopHistoryDaoImpl();
	
	/**
	 * 根据用户id获取交易记录
	 * @param userId
	 * @return
	 */
	public List<ShopHistory> getShopHistory(Integer userId) {
		List<ShopHistory> shopHistoryLists = shopHistoryDao.getShopHistory(userId);
		return shopHistoryLists;
	}

}
