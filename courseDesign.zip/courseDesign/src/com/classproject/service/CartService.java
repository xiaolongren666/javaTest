package com.classproject.service;

import java.util.List;

import com.classproject.DaoImpl.CartDaoImpl;
import com.classproject.dao.CartDao;
import com.classproject.domain.Book;
import com.classproject.domain.Cart;
import com.classproject.domain.Order;

public class CartService {
	CartDao cartDao = new CartDaoImpl();

	// 获得购物车中的所有条目
	public List<Cart> carts(int userId) {
		List<Cart> carts = cartDao.carts(userId);
		return carts;
	}

	//根据购物车id查找用户购物车中的商品数目
	public long GetUserShopCout(int cartId){
		 long i = cartDao.GetUserShopCout(cartId);
		return i;
	}
	
	// 根据用户id获得购物车id
	public int GetUserCartId(int userId) {
		int cartId = cartDao.GetUserCartId(userId);
		return cartId;
	}

	// 根据书名查找到书号、书题和书价
	public List<Book> GetBookTitleAndPrice(String bookName) {
		List<Book> GetBookTitleAndPrice = cartDao.GetBookTitleAndPrice(bookName);
		return GetBookTitleAndPrice;
	}

	// 根据用户选择的书籍id去检查该用户的购物车中是否存在该商品
	public Integer ifHaveThisBook(int userId, int bookId) {
		int i = cartDao.ifHaveThisBook(userId, bookId);
		return i;
	}

	// 如果用户的购物车中存在该书籍，就获取到该书籍的数量，返回count的值
	public Integer SelectThisBookCount(int userId, int bookId) {
		int thisBookCount = cartDao.SelectThisBookCount(userId, bookId);
		return thisBookCount;
	}

	// 将count的值加1，执行更新操作
	public void UpdateThisBookCount(int count, int bookId, int cartId) {
		cartDao.UpdateThisBookCount(count, bookId, cartId);
	}
	// 如果用户的购物车中不存在该书籍，就执行插入操作，count为1
	public void InsertBookToCart(int cartId, int bookId, String bookName, String bookTitle, float bookPrice,
			int count) {
		cartDao.InsertBookToCart(cartId, bookId, bookName, bookTitle, bookPrice, count);
	}

	// 对购物车中的条目进行删除操作
	public void DeleteBookToCart(int cartId, int bookId) {
		cartDao.DeleteBookToCart(cartId, bookId);
	}

	// 将选定的商品添加到订单表
	public void addThisBookToOrder(String userName, int bookId, String bookName, float bookPrice, int bookCount) {
		cartDao.addThisBookToOrder(userName, bookId, bookName, bookPrice, bookCount);
	}

	// 查询该用户有多少笔账单
	public long selectUserOrders(String userName) {
		long orderCount = cartDao.selectUserOrders(userName);
		return orderCount;
	}

	// 根据用户账单算出订单总额
	public Double GetTotalAmount(String userName) {
		Double totalAmount = cartDao.GetTotalAmount(userName);
		return totalAmount;
	}

	// 根据用户名查找订单详细条目
	public List<Order> orders(String userName) {
		List<Order> orders = cartDao.orders(userName);
		return orders;
	}
}
