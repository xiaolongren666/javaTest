package com.classproject.domain;

public class Acount {
	private int acountId;
	private float blance;
	private int userId;

	public int getAcountId() {
		return acountId;
	}

	public void setAcountId(int acountId) {
		this.acountId = acountId;
	}

	public float getBlance() {
		return blance;
	}

	public void setBlance(float blance) {
		this.blance = blance;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Acount [acountId=" + acountId + ", blance=" + blance + ", userId=" + userId + "]";
	}

}
