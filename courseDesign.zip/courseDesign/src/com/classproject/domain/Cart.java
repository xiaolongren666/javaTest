package com.classproject.domain;

public class Cart {
	private int cartId;// 购物车id
	private int bookId;// 购物车中的书号
	private String bookName;// 购物车中的书名
	private String bookTitle;// 购物车中的书标题
	private String bookPrice;// 购物车中书的价格
	private int count;// 购物车中书的数量

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(String bookPrice) {
		this.bookPrice = bookPrice;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", bookId=" + bookId + ", bookName=" + bookName + ", bookTitle=" + bookTitle
				+ ", bookPrice=" + bookPrice + ", count=" + count + "]";
	}

}
