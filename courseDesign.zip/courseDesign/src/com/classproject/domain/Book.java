package com.classproject.domain;

import java.sql.Date;

public class Book {

	private Integer bookId;// 书号
	private String name;// 书名
	private String author;// 作者
	private String title;// 标题
	private Integer price;// 价格
	private Date publishDate;// 上市日期
	private Integer salesAmount;// 销量
	private Integer stock;// 库存

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public Integer getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(Integer salesAmount) {
		this.salesAmount = salesAmount;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", name=" + name + ", author=" + author + ", title=" + title + ", price="
				+ price + ", publishDate=" + publishDate + ", salesAmount=" + salesAmount + ", stock=" + stock + "]";
	}

}
