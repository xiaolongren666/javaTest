package com.classproject.domain;

public class Order {
	private int orderId;
	private String userName;
	private int bookId;

	private String bookName;
	private float bookPrice;
	private int bookCount;

	public int getOrderId() {
		return orderId;
	}
	
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public float getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(float bookPrice) {
		this.bookPrice = bookPrice;
	}

	public int getBookCount() {
		return bookCount;
	}

	public void setBookCount(int bookCount) {
		this.bookCount = bookCount;
	}

	@Override
	public String toString() {
		return "order [orderId=" + orderId + "userName=" + userName + ", bookId=" + bookId + ", bookName=" + bookName + ", bookPrice="
				+ bookPrice + ", bookCount=" + bookCount + "]";
	}

}
