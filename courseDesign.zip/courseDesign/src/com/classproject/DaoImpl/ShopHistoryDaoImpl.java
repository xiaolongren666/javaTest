package com.classproject.DaoImpl;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.classproject.dao.ShopHistoryDao;
import com.classproject.domain.ShopHistory;
import com.classproject.tools.JdbcUtil;

public class ShopHistoryDaoImpl implements ShopHistoryDao {

	private QueryRunner queryRunner = new QueryRunner();
	
	public void insert(ShopHistory shophistory) {
		Connection connection = null;
		String sql = "INSERT into shophistory (userId,userName,description,shopTime) VALUES (?, ?, ?, ?)";
		try {
			connection = JdbcUtil.getConnection();
			queryRunner.update(connection, sql, new Object[] { shophistory.getUserId(),
															   shophistory.getUserName(), 
															   shophistory.getDescription(), 
															   shophistory.getShopTime() });
		} catch (Exception e) {	
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	/**
	 * 根据用户id获取交易记录
	 */
	@Override
	public List<ShopHistory> getShopHistory(Integer userId) {
		Connection connection = null;
		String sql = "SELECT userId,userName,description,shopTime FROM shophistory WHERE userId=?";
		try {
			connection = JdbcUtil.getConnection();
			return (List<ShopHistory>) queryRunner.query(connection, sql, new BeanListHandler(ShopHistory.class),
														 new Object[]{ userId });

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

}
