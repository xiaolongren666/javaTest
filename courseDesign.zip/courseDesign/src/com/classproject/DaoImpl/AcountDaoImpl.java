package com.classproject.DaoImpl;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.classproject.dao.AcountDao;
import com.classproject.domain.Acount;
import com.classproject.tools.JdbcUtil;

public class AcountDaoImpl implements AcountDao {

	QueryRunner queryrunner = new QueryRunner();

	// 根据用户id查询账户id，返回账户id
	public int getUserAcountId(int userId) {
		int userAcountId = 0;
		Connection connection = null;
		String sql = "SELECT acountId FROM acount WHERE userId = ?";
		try {
			connection = JdbcUtil.getConnection();
			userAcountId = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId });
			return userAcountId;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return 0;
	}

	// 得到用户账户的余额
	public List<Acount> acounts(int acountId, int userId) {
		Connection connection = null;
		String sql = "SELECT acountId,blance,userId FROM acount WHERE acountId = ? AND userId = ?";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Acount>) queryrunner.query(connection, sql, new BeanListHandler(Acount.class),
					new Object[] { acountId, userId });

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	// 进行账户充值
	public void AcountRecharge(float finalAmount, int acountId, int userId) {
		Connection connection = null;
		String sql = " UPDATE acount SET blance = ? WHERE acountId = ? AND userId = ?";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { finalAmount, acountId, userId });
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("请检查充值的账户是否正确。。。。");
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	public Acount getUserAcountById(Integer userId) {
		int userAcountId = 0;
		Connection connection = null;
		String sql = "SELECT acountId,blance,userId FROM acount WHERE userId = ?";
		try {
			connection = JdbcUtil.getConnection();
			Acount acount = (Acount) queryrunner.query(connection, sql, new BeanHandler(Acount.class), new Object[] { userId });
			return acount;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	public void updateBlance(Acount acount) {
		Connection connection = null;
		String sql = " UPDATE acount SET blance = ? WHERE acountId = ? AND userId = ?";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { acount.getBlance(), acount.getAcountId(), acount.getUserId() });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

}
