package com.classproject.DaoImpl;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.classproject.dao.CartDao;
import com.classproject.domain.Book;
import com.classproject.domain.Cart;
import com.classproject.domain.Order;
import com.classproject.tools.JdbcUtil;

public class CartDaoImpl implements CartDao {

	QueryRunner queryrunner = new QueryRunner();

	// 遍历出购物车中所有的条目
	@SuppressWarnings("unchecked")
	public List<Cart> carts(int userId) {
		Connection connection = null;
		String sql = "SELECT shopcartitem.cartId,bookId,bookName,bookTitle,bookPrice,count FROM shopcart,shopcartitem WHERE shopcart.userId=? AND shopcart.cartId = shopcartitem.cartId";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Cart>) queryrunner.query(connection, sql, new BeanListHandler(Cart.class),
					new Object[] { userId });

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}
	
	//根据购物车id查找用户购物车中的商品数目
	public long GetUserShopCout(int cartId) {
		Connection connection = null;
		String sql = "SELECT count(*) FROM shopcartitem WHERE cartId = ?";
		try {
			connection = JdbcUtil.getConnection();
			return (Long)queryrunner.query(connection, sql, new ScalarHandler(),new Object[]{cartId});
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return 0;
	}

	// 根据用户id获取购物车id
	public Integer GetUserCartId(int userId) {
		int cartId = 0;
		Connection connection = null;
		String sql = "SELECT cartId FROM shopcart WHERE userId=?";
		try {
			connection = JdbcUtil.getConnection();
			cartId = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return cartId;
	}

	// 根据书名查找到书题和书价
	public List<Book> GetBookTitleAndPrice(String bookName) {
		Connection connection = null;
		String sql = "SELECT bookId,title,price FROM book WHERE name=?";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Book>) queryrunner.query(connection, sql, new BeanListHandler(Book.class),
					new Object[] { bookName });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	// 根据用户选择的书籍id去检查该用户的购物车中是否存在该商品
	public Integer ifHaveThisBook(int userId, int bookId) {
		Connection connection = null;
		int i = 0;
		String sql = "SELECT shopcartitem.bookId FROM shopcart,shopcartitem WHERE userId = ? AND bookId = ? AND shopcart.cartId = shopcartitem.cartId";
		try {
			connection = JdbcUtil.getConnection();
			i = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId, bookId });
			System.out.println("查询执行结果" + i);
		} catch (Exception e) {
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return i;
	}

	// 如果存在该书籍，就获取到该书籍的数量，返回count的值
	public Integer SelectThisBookCount(int userId, int bookId) {
		Connection connection = null;
		int i = 0;
		String sql = "SELECT count FROM shopcart,shopcartitem  WHERE userId = ? AND shopcart.cartId = shopcartitem.cartId AND shopcartitem.bookId = ?";
		try {
			connection = JdbcUtil.getConnection();
			i = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId, bookId });
			return i;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}
	public Integer SelectThisBookPrice(int userId, int bookId) {
		Connection connection = null;
		int i = 0;
		String sql = "SELECT bookPrice FROM shopcart,shopcartitem  WHERE userId = ? AND shopcart.cartId = shopcartitem.cartId AND shopcartitem.bookId = ?";
		try {
			connection = JdbcUtil.getConnection();
			i = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId, bookId });
			return i;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	// 将count的值加1，执行更新操作
	public void UpdateThisBookCount(int count, int bookId, int cartId) {
		Connection connection = null;
		String sql = "UPDATE shopcartitem SET count = ? WHERE bookId =?  AND cartId = ?";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { count, bookId, cartId });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}
	// 如果用户的购物车中不存在该书籍，就执行插入操作，count为1
	public void InsertBookToCart(int cartId, int bookId, String bookName, String bookTitle, float bookPrice,
			int count) {
		Connection connection = null;
		String sql = "INSERT INTO shopcartitem VALUES (?, ?, ?, ?, ?, ?)";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { cartId, bookId, bookName, bookTitle, bookPrice, count });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	// 对购物车中的条目进行删除操作
	public void DeleteBookToCart(int cartId, int bookId) {
		Connection connection = null;
		String sql = "DELETE FROM shopcartitem WHERE cartId = ? AND bookId = ?";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { cartId, bookId });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	// 将选中的商品条目添加到订单表
	public void addThisBookToOrder(String userName, int bookId, String bookName, float bookPrice, int bookCount) {
		Connection connection = null;
		String sql = "INSERT INTO `order`(userName,bookId,bookName,bookPrice,bookCount) VALUES(?,?,?,?,?)";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { userName, bookId, bookName, bookPrice, bookCount });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}

	}

	// 查询用户一共有多少笔账单
	public long selectUserOrders(String userName) {
		long i = 0;
		Connection connection = null;
		String sql = "SELECT COUNT(*) FROM `order` WHERE userName = ?";
		try {
			connection = JdbcUtil.getConnection();
			i = (Long) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userName });
			return i;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return 0;
	}

	// 根据用户订单算出订单总额
	public Double GetTotalAmount(String userName) {
		Double totalAmount = 0.00;
		Connection connection = null;
		String sql = "SELECT SUM(bookPrice) FROM `order` WHERE userName=?";//这个语句有问题！
		try {
			connection = JdbcUtil.getConnection();
			totalAmount = (Double) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userName });
			return totalAmount;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return 0.00;
	}

	// 订单条目的详细查询
	public List<Order> orders(String userName) {
		Connection connection = null;
		String sql = "SELECT * FROM `order` WHERE userName = ?";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Order>) queryrunner.query(connection, sql, new BeanListHandler(Order.class),
					new Object[] { userName });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	

}
