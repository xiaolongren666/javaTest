package com.classproject.DaoImpl;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.classproject.dao.OrderDao;
import com.classproject.domain.Order;
import com.classproject.tools.JdbcUtil;

public class OrderDaoImpl implements OrderDao {

	private QueryRunner queryRunner = new QueryRunner();
	public List<Order> getorder() {
		Connection connection = null;
		String sql = "SELECT orderId,userName,bookId,bookName,bookPrice,bookCount FROM `order`";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Order>) queryRunner.query(connection, sql, new BeanListHandler(Order.class));

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
		
	}
	public void clean() {
		Connection connection = null;
		String sql = "DELETE FROM `order`";
		try {
			connection = JdbcUtil.getConnection();
			queryRunner.update(connection, sql);

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}
	
	/**
	 * 查看订单是否存在
	 */
	@Override
	public boolean checkIfOrder() {
		List<Order> orders = getorder();
		if(orders.size() == 0) {
			return false;
		}
		return true;
	}
	
	/**
	 * 删除指定订单
	 */
	@Override
	public void deleteOrderToOrders(int orderId) {
		Connection connection = null;
		String sql = "DELETE FROM `order` WHERE orderId=?";
		System.out.println();
		try {
			connection = JdbcUtil.getConnection();
			queryRunner.update(connection, sql, new Object[] { orderId });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}
}
