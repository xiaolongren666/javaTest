package com.classproject.DaoImpl;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.classproject.dao.BookDao;
import com.classproject.domain.Book;
import com.classproject.tools.JdbcUtil;

public class BookDaoImpl implements BookDao {

	QueryRunner queryrunner = new QueryRunner();

	// 遍历出数据库中所有的书籍
	public List<Book> list() {

		Connection connection = null;
		String sql = "select bookId,name,author,title,price,publishDate,salesAmount,stock from book";
		try {
			connection = JdbcUtil.getConnection();
			return (List<Book>) queryrunner.query(connection, sql, new BeanListHandler(Book.class));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	// 条件检索书籍
	@SuppressWarnings("unchecked")
	public List<Book> SerachBookByCondition(String author, String title, String name, String price1, String price2) {
		Connection connection = null;
		StringBuffer buffer = new StringBuffer();
		buffer.append("select bookId,`name`,author,title,price,publishDate,salesAmount from book WHERE 1=1");

		if(author != null && !"".equals(author)) {
			buffer.append(" and author like '%" + author + "%'");
			
		}
		
		if(title != null && !"".equals(title)) {
			buffer.append(" and title like '%" + title + "%'");
			
		}
		if(name != null && !"".equals(name)) {
			buffer.append(" and name like '%" + name + "%'");
			
		}
		if(price1 != null && !"".equals(price1) && price2 != null && !"".equals(price2)) {
			buffer.append(" and price BETWEEN "+ price1 +" AND " + price2);
		}
		System.out.println(buffer);
		String sql = buffer.toString();
		try {
			connection = JdbcUtil.getConnection();
			return (List<Book>) queryrunner.query(connection, sql, new BeanListHandler(Book.class));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
		return null;
	}

	
	/**
	 * 根据图书号删除图书
	 */
	@Override
	public void deleteBook(Integer bookId) {
		Connection connection = null;
		String sql = "DELETE FROM book WHERE bookId = ?";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { bookId });
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.releaseConnection(connection);
		}
	}


}
