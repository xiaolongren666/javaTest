package com.classproject.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.classproject.dao.UserDao;
import com.classproject.domain.User;
import com.classproject.tools.JdbcUtil;

public class UserDaoImpl implements UserDao {

	QueryRunner queryrunner = new QueryRunner();

	// 用户的登录
	public Integer login(User user) {
		Connection connection = null;
		int i = 0;
		String sql = "select userId from user where userName=? and `password`=?";
		try {
			connection = JdbcUtil.getConnection();
			i = (Integer) queryrunner.query(connection, sql, new ScalarHandler(),
					new Object[] { user.getUserName(), user.getPassword() });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
		return i;
	}

	// 用户的注册
	public long insertUser(User user) {
		long id = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String sql = "INSERT into user (userName,userSex,userEmail,password,registTime) VALUES(?,?,?,?,?)";
		Object[] args = new Object[] { user.getUserName(), user.getUserSex(), user.getUserEmail(), user.getPassword(),
				user.getRegistTime() };
		try {

			connection = JdbcUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					preparedStatement.setObject(i + 1, args[i]);
				}
			}
			preparedStatement.executeUpdate();
			// 插入用户记录时获得主键的值
			resultSet = preparedStatement.getGeneratedKeys();
			if (resultSet.next()) {
				id = resultSet.getLong(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.release(resultSet, preparedStatement);
			JdbcUtil.releaseConnection(connection);
		}
		return id;
	}

	// 用户注册成功后用用户的id创建一个唯一的购物车
	public void creatShopCart(int userId) {
		Connection connection = null;
		System.out.println("新注册用户的Id为" + userId + "已创建购物车");
		String sql = "INSERT INTO shopcart(userId) VALUES(?)";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { userId });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	// 用户注册成功后用用户的id创建一个唯一的用户账户
	public void createUserAcount(int userId, float blance) {
		Connection connection = null;
		System.out.println("新注册用户的Id为" + userId + "已创建个人账户");
		String sql = "INSERT INTO acount(userId,blance) VALUES(?,?)";
		try {
			connection = JdbcUtil.getConnection();
			queryrunner.update(connection, sql, new Object[] { userId, blance });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
	}

	// 根据用户的id查询用户的个人信息
	public Integer selectUserInfor(int userId) {
		Connection connection = null;
		int i = 0;
		String sql = "select  userName,userSex,userEmail from user where userId=?";
		try {
			connection = JdbcUtil.getConnection();
			i = (Integer) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
		return i;
	}

	/**
	 * 根据用户id获取注册时间
	 */
	@Override
	public Date getRegisterTime(int userId) {
		Connection connection = null;
		Date registerTime = null;
		String sql = "select registTime from user where userId=?";
		try {
			connection = JdbcUtil.getConnection();
			registerTime = (Date) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
		return registerTime;
	}

	/**
	 * 根据用户id获取用户权限
	 */
	@Override
	public long getRoleld(Integer userId) {
		Connection connection = null;
		long roleId = 0;
		String sql = "select roleId from `user` where userId=?";
		try {
			connection = JdbcUtil.getConnection();
			roleId = (long) queryrunner.query(connection, sql, new ScalarHandler(), new Object[] { userId });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.releaseConnection(connection);
		}
		return roleId;
	}
}