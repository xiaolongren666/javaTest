/**
 * 
 */
package com.classproject.tools;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.classproject.domain.Order;
import com.classproject.service.CartService;

/*
*@Author:小龙人
*@File Name:GetShopCountUtil.java
*@Created Time:下午3:08:31
*@Introduce Function:TODO
*/
public class CommonUtil {
	
	private static CartService cartService = new CartService();
	
	/**
	 * 获取购物车商品的数量
	 * @return
	 */
	public static long getShopCount(HttpServletRequest request) {
		Integer userid = (Integer)request.getSession().getAttribute("userid");
		int cartId = cartService.GetUserCartId(userid);
		long shopCount = cartService.GetUserShopCout(cartId);
		return shopCount;
	}
	
	public static float getOrderTotalMemoney(String userName) {
		float acunt = 0;
		List<Order> orders = cartService.orders(userName);
		for (Order order : orders) {
			acunt += order.getBookPrice();
		}
		return acunt;
	}
	
}
