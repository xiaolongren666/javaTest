package com.classproject.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.classproject.domain.Book;
import com.classproject.domain.Cart;
import com.classproject.domain.Order;
import com.classproject.service.AcountService;
import com.classproject.service.BookService;
import com.classproject.service.CartService;
import com.classproject.service.OrderService;
import com.classproject.tools.CommonUtil;

public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CartServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("method");
		System.out.println(methodName);
		try {
			Method method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			// 获取私有成员变量
			method.setAccessible(true);
			method.invoke(this, request, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}

	}

	CartService cartService = new CartService();
	BookService bookService = new BookService();

	// 将用户选择的书籍添加到购物车
	protected void AddShopCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取当前登录用户的id
		int userId = (Integer) request.getSession().getAttribute("userid");

		// 获取用户选择的书的一些信息
		String bookName = request.getParameter("bookName");
		String bookTitle = null;
		Integer bookId = 0;
		Integer bookPrice = 0;

		// 调用方法，传入用户id，返回用户的购物车id和该用户购物车中的条目
		int userCartId = cartService.GetUserCartId(userId);
		List<Cart> carts = cartService.carts(userId);

		// 调用方法，传入书名，返回该书的书题和书价
		List<Book> GetBookTitleAndPrice = cartService.GetBookTitleAndPrice(bookName);
		for (Book book : GetBookTitleAndPrice) {
			bookTitle = book.getTitle();
			bookPrice = book.getPrice();
			bookId = book.getBookId();
		}

		// 添加书籍之前先判断用户的购物车中是否有该商品
		int i = 0;
		i = cartService.ifHaveThisBook(userId, bookId);

		// 如果用户的购物车中存在该书籍，就获取到该书籍的数量，返回
		if (i != 0) {
			int thisBookCount = cartService.SelectThisBookCount(userId, bookId);
			System.out.println("当前用户购物车中已存在该书籍，数量为：" + thisBookCount);
			System.out.println("执行更新操作");

			System.out.println(thisBookCount++);
			// 将count的值加1，执行更新操作
			cartService.UpdateThisBookCount(thisBookCount++, bookId, userCartId);

			List<Book> list = bookService.list();
			request.setAttribute("list", list);
			
			long shopCout = CommonUtil.getShopCount(request);
			request.setAttribute("shopCout", shopCout);
	
			// 重定向到当前页面，继续购物
			request.getRequestDispatcher("/WEB-INF/page/content.jsp").forward(request, response);
			return;
		}

		// 如果购物车中不存在该书，说明是用户第一次添加，就执行插入操作
		else {
			
			cartService.InsertBookToCart(userCartId, bookId, bookName, bookTitle, bookPrice, 1);
			List<Book> list = bookService.list();
			
			// 重定向到当前页面，继续购物
			request.setAttribute("list", list);
			
			long shopCout = CommonUtil.getShopCount(request);
			request.setAttribute("shopCout", shopCout);
			request.getRequestDispatcher("/WEB-INF/page/content.jsp").forward(request, response);
			return;
		}

	}

	// 在我的购物车页面执行修改书籍数量的操作
	protected void UpdateBookCurrentCount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得修改后的数量
		String currentCount = request.getParameter("count");
		System.out.println(currentCount);
		// 获得bookId
		String bookName = request.getParameter("bookName");
		System.out.println(bookName);
		int bookId = 0;
		List<Book> GetBookTitleAndPrice = cartService.GetBookTitleAndPrice(bookName);
		for (Book book : GetBookTitleAndPrice) {
			bookId = book.getBookId();
		}
		System.out.println(bookId);
		// 获得cartId
		int userId = (Integer) request.getSession().getAttribute("userid");
		int userCartId = cartService.GetUserCartId(userId);
		System.out.println(userCartId);
		// 执行更新操作
		cartService.UpdateThisBookCount(Integer.parseInt(currentCount), bookId, userCartId);
		// 跳转到我的购物车页面，继续操作
		List<Cart> carts = cartService.carts(userId);
		request.setAttribute("carts", carts);
		request.getRequestDispatcher("/WEB-INF/page/shopCart.jsp").forward(request, response);
	}

	// 在我的购物车页面执行删除书籍的操作
	protected void DeleteBookToCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得bookId
		String bookName = request.getParameter("bookName");
		System.out.println(bookName);
		int bookId = 0;
		List<Book> GetBookTitleAndPrice = cartService.GetBookTitleAndPrice(bookName);
		for (Book book : GetBookTitleAndPrice) {
			bookId = book.getBookId();
		}
		System.out.println(bookId);
		// 获得cartId
		int userId = (Integer) request.getSession().getAttribute("userid");
		int userCartId = cartService.GetUserCartId(userId);
		System.out.println(userCartId);
		// 执行删除操作
		cartService.DeleteBookToCart(userCartId, bookId);
		// 跳转到我的购物车页面，继续操作
		List<Cart> carts = cartService.carts(userId);
		request.setAttribute("carts", carts);
		// 显示商品数量
		long shopCout = CommonUtil.getShopCount(request);
		request.setAttribute("shopCout", shopCout);
		request.getRequestDispatcher("/WEB-INF/page/shopCart.jsp").forward(request, response);
	}

	// 将选择好的商品条目创建订单
	protected void addThisBookToOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		float acunt=0;
		// 获取用户名
		String userName = (String) request.getSession().getAttribute("username");
		// 获取书籍id，名称和价格
		String bookName = request.getParameter("bookName");
		int bookId = 0;
		float bookPrice = 0;
		List<Book> GetBookTitleAndPrice = cartService.GetBookTitleAndPrice(bookName);
		for (Book book : GetBookTitleAndPrice) {
			bookId = book.getBookId();
			bookPrice = book.getPrice();
		}
		// 得到当前书的数量
		int userId = (Integer) request.getSession().getAttribute("userid");
		int bookCount = cartService.SelectThisBookCount(userId, bookId);
		// 执行添加到订单表的操作
		cartService.addThisBookToOrder(userName, bookId, bookName, bookPrice, bookCount);
		// 查询有多少笔订单
		long i = cartService.selectUserOrders(userName);
		// 删除当前购物车中的商品条目
		int userCartId = cartService.GetUserCartId(userId);
		cartService.DeleteBookToCart(userCartId, bookId);
		// 跳转到我的购物车页面，继续操作
		List<Cart> carts = cartService.carts(userId);
		Double totalAmount = (double) (bookCount * bookPrice);
		List<Order> orders = cartService.orders(userName);
		request.setAttribute("carts", carts);
		request.setAttribute("orderCounts", i);
		request.setAttribute("totalAmount", totalAmount);
		acunt = CommonUtil.getOrderTotalMemoney(userName);
		request.getSession().setAttribute("acunt", acunt);
		// 显示购物车商品数目
		long shopCout = CommonUtil.getShopCount(request);
		request.setAttribute("shopCout", shopCout);
		request.setAttribute("orders", orders);
		request.getRequestDispatcher("/WEB-INF/page/shopCart.jsp").forward(request, response);
	}

	AcountService acountService = new AcountService();
	OrderService orderService = new OrderService();
	// 结账
	protected void checkout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String totalAmount = request.getParameter("totalAmount");
		Integer userId = (Integer) request.getSession().getAttribute("userid");
		String username = (String) request.getSession().getAttribute("username");
		// 检查订单是否存在
		boolean ifOrders = orderService.checkIfOrder();
		if(false == ifOrders){
			String msg = "操作失败！木有订单生成!!3秒后跳转到购物车页面。。。。。";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/WEB-INF/page/success.jsp").forward(request, response);
			return;
		}
		
		int i = acountService.totalAmount(userId, Float.valueOf(totalAmount), username);
		if (i == 0) {
			request.getRequestDispatcher("/WEB-INF/page/creditLow.jsp").forward(request, response);
			return;
		} else if (i == 1) {
			String msg = "操作成功,3秒后跳转到购物车页面。。。。。";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/WEB-INF/page/success.jsp").forward(request, response);
			return;
		}
	}
}
