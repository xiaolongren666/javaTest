package com.classproject.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.classproject.domain.Cart;
import com.classproject.domain.Order;
import com.classproject.service.CartService;
import com.classproject.service.OrderService;
import com.classproject.tools.CommonUtil;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("method");
		System.out.println(methodName);
		try {
			Method method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			// 获取私有成员变量
			method.setAccessible(true);
			method.invoke(this, request, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	
	}
	
	OrderService orderService = new OrderService();
	CartService cartService = new CartService();
	/**
	 * 删除订单中的订单
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void deleteOrderToOrders(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// 获得bookId
		int orderId = Integer.parseInt(request.getParameter("orderId"));
		int userid = (Integer) request.getSession().getAttribute("userid");
		// 得到购物车详细条目
		List<Cart> carts = cartService.carts(userid);
		String userName = (String) request.getSession().getAttribute("username");
		// 删除指定订单
		orderService.deleteOrderToOrders(orderId);
		// 得到订单总数
		long i = cartService.selectUserOrders(userName);
		// 得到订单总额
		Double totalAmount = cartService.GetTotalAmount(userName);
		// 得到订单
		List<Order> orders = orderService.getOrder();
		// 显示订单总数
		request.setAttribute("orderCounts", i);
		// 显示订单总金额
		request.setAttribute("totalAmount", totalAmount);
		// 显示购物车详细条目
		request.setAttribute("carts", carts);
		request.setAttribute("orders", orders);
		// 显示商品数量
		long shopCout = CommonUtil.getShopCount(request);
		request.setAttribute("shopCout", shopCout);
		// 显示订单总金额
		float acunt = CommonUtil.getOrderTotalMemoney(userName);
		request.getSession().setAttribute("acunt", acunt);
		request.getRequestDispatcher("/WEB-INF/page/shopCart.jsp").forward(request, response);
		}
}
