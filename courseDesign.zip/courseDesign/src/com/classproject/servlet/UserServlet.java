package com.classproject.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.classproject.domain.Acount;
import com.classproject.domain.Book;
import com.classproject.domain.Cart;
import com.classproject.domain.Order;
import com.classproject.domain.ShopHistory;
import com.classproject.domain.User;
import com.classproject.service.AcountService;
import com.classproject.service.BookService;
import com.classproject.service.CartService;
import com.classproject.service.ShopHistoryService;
import com.classproject.service.UserService;
import com.classproject.tools.CommonUtil;

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("method");

		try {
			Method method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			// 获取私有成员变量
			method.setAccessible(true);
			method.invoke(this, request, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);

		}
	}

	BookService bookService = new BookService();
	UserService userService = new UserService();
	CartService cartService = new CartService();
	AcountService acountService = new AcountService();
	ShopHistoryService shopHistoryService = new ShopHistoryService(); 

	// 验证用户并登录
	protected void denglu(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if ("".equals(username.trim()) || "".equals(password.trim())) {
			request.getRequestDispatcher("/WEB-INF/page/login.jsp").forward(request, response);
			return;
		}

		User user = new User();
		user.setUserName(username);
		user.setPassword(password);
		Integer userid = userService.login(user);
		long roleId = userService.getRoleld(userid);
		
		List<Book> list = bookService.list();
		request.setAttribute("list", list);

		if (userid != 0) {
			// 登陆成功后将用户名保存到session中，在整个会话期间都可以访问到
			request.getSession().setAttribute("username", username);
			// 登陆成功后将用户id保存到session中，在整个会话期间都可以访问到
			request.getSession().setAttribute("userid", userid);
			// 登陆成功后保存用户权限
			request.getSession().setAttribute("roleId", roleId);
			

			long shopCout = CommonUtil.getShopCount(request);
			request.setAttribute("shopCout", shopCout);
			
			request.getRequestDispatcher("/WEB-INF/page/content.jsp").forward(request, response);
			return;
		}
		request.getRequestDispatcher("/WEB-INF/page/login.jsp").forward(request, response);
		return;
	}

	// 实现用户注册
	protected void zhuce(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		// 获取用户输入的值
		String userName = request.getParameter("regigterUsername");
		String userSex = request.getParameter("regigterSex");
		String userEmail = request.getParameter("regigterEmail");
		String userPassword = request.getParameter("regigterPassword");

		User user = new User();
		user.setUserName(userName);
		user.setPassword(userPassword);
		user.setUserEmail(userEmail);
		user.setUserSex(userSex);
		user.setRegistTime(new Date());

		userService.insertUser(user, 0);
		request.getRequestDispatcher("/WEB-INF/page/login.jsp").forward(request, response);
		return;

	}

	// 跳转到注册页
	protected void zhuceye(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		request.getRequestDispatcher("/WEB-INF/page/register.jsp").forward(request, response);
		return;
	}

	// 跳转到我的购物车页
	protected void myShopCart(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		int userid = (Integer) request.getSession().getAttribute("userid");
		// 得到购物车详细条目
		List<Cart> carts = cartService.carts(userid);
		String userName = (String) request.getSession().getAttribute("username");
		// 得到订单总数
		long i = cartService.selectUserOrders(userName);
		// 得到订单总额
		Double totalAmount = cartService.GetTotalAmount(userName);
		// 得到订单详细条目
		List<Order> orders = cartService.orders(userName);
		System.out.println(orders);
	
		// 显示购物车详细条目
		request.setAttribute("carts", carts);
		// 显示订单总数
		request.setAttribute("orderCounts", i);
		// 显示订单总金额
		request.setAttribute("totalAmount", totalAmount);
		// 显示订单详细条目
		request.setAttribute("orders", orders);
		// 显示购物车商品数目
		long shopCout = CommonUtil.getShopCount(request);
		request.setAttribute("shopCout", shopCout);
		// 显示订单总金额
		float acunt = CommonUtil.getOrderTotalMemoney(userName);
		request.getSession().setAttribute("acunt", acunt);
		request.getRequestDispatcher("/WEB-INF/page/shopCart.jsp").forward(request, response);
		return;
	}

	// 跳转到我的账户页
	protected void userCount(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 得到该用户的账户id
		int userId = (Integer) request.getSession().getAttribute("userid");
		int userAcountId = acountService.getUserAcountId(userId);
		// 查询该用户的账户余额
		List<Acount> acounts = acountService.acounts(userAcountId, userId);
		System.out.println(acounts);
		// 将查询结果显示在前端页面
		request.setAttribute("acounts", acounts);
		// 显示商品数量
		long shopCout = CommonUtil.getShopCount(request);
		request.setAttribute("shopCout", shopCout);
		// 显示用户注册时间
		Date registerTime = userService.getRegisterTime(userId);
		request.setAttribute("registerTime", registerTime);
		// 显示交易记录
		List<ShopHistory> shopHistoryLists = shopHistoryService.getShopHistory(userId);
		request.setAttribute("shopHistoryLists", shopHistoryLists);
		// 转发到我的账户页面
		request.getRequestDispatcher("/WEB-INF/page/userAcount.jsp").forward(request, response);
	}
	
	
	protected void turnOff(HttpServletRequest request, HttpServletResponse response) 
			throws IOException, ServletException {
		request.getSession().removeAttribute("username");
		request.getSession().removeAttribute("userid");
		response.sendRedirect("index.jsp");
		return;
	}
}
