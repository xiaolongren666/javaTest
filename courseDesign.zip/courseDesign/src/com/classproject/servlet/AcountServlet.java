package com.classproject.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.classproject.domain.Acount;
import com.classproject.domain.Book;
import com.classproject.domain.User;
import com.classproject.service.AcountService;
import com.classproject.service.BookService;
import com.classproject.service.UserService;

public class AcountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AcountServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("method");
		try {
			Method method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			// 获取私有成员变量
			method.setAccessible(true);
			method.invoke(this, request, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);

		}
	}

	AcountService acountService = new AcountService();
	UserService userService = new UserService();
	BookService bookService = new BookService();

	// 进行用户账户充值的操作
	protected void AcountRecharge(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		System.out.println("访问 了用户充值的servlet");

		// 得到用户当前账户余额
		float blance = 0;
		int userId = (Integer) request.getSession().getAttribute("userid");
		int userAcountId = acountService.getUserAcountId(userId);
		List<Acount> acounts = acountService.acounts(userAcountId, userId);
		for (Acount acount : acounts) {
			blance = acount.getBlance();
		}
		System.out.println(blance);

		// 得到用户填写的充值金额
		float rechargeAmount = Float.parseFloat(request.getParameter("rechargeAmount"));
		rechargeAmount += blance;
		System.out.println(rechargeAmount);

		// 进行用户名和密码的匹配
		String username = request.getParameter("userName");
		String password = request.getParameter("userPassword");
		System.out.println(username + password);
		User user = new User();
		user.setUserName(username);
		user.setPassword(password);
		Integer i = userService.login(user);

		// 根据匹配结果执行不同的操作
		if (i != 0) {
			acountService.AcountRecharge(rechargeAmount, userAcountId, userId);
			// 跳转到书城主页
			List<Book> list = bookService.list();
			request.setAttribute("list", list);
			request.getRequestDispatcher("/WEB-INF/page/content.jsp").forward(request, response);
		} else {
			request.getRequestDispatcher("/WEB-INF/page/error.jsp").forward(request, response);
		}

	}
}
