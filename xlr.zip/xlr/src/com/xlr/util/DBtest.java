/**
 * 
 */
package com.xlr.util;

import java.sql.Connection;

/*
*@Author:小龙人
*@File Name:DBtest.java
*@Created Time:下午7:44:18
*@Introduce Function:TODO
*/
public class DBtest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection conn = JDBCUtil.getConnection();
		
		System.out.println("成功过了");
	}

}
