/**
 * 
 */
package com.xlr.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.xlr.model.User;

/*
*@Author:小龙人
*@File Name:JDBCUtil.java
*@Created Time:上午12:57:17
*@Introduce Function:连接数据库
*/

/**
 * JDBC连接数据库封装类
 * 
 * @author Administrator
 * 
 */
public class JDBCUtil {
	// for orcale
	// private static final String driver ="oracle.jdbc.driver.OracleDriver";
	// private static final String url
	// ="jdbc:oracle:thin:@192.168.0.80:1522:qst";
	// private static final String username ="yxd";
	// private static final String password ="yxd";

	// sql server
	private static final String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static final String url = "jdbc:sqlserver://localhost:1433;DatabaseName=test";
	private static final String username = "sa";
	private static final String password = "sa";

	PreparedStatement pstmt;
	ResultSet rs;
	Statement stmt;
	
	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(driver);
			System.out.println("加载驱动成功");
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("建立数据库成功");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	public static void close(Connection conn, Statement stmt, PreparedStatement pstmt, ResultSet rs) {
		try {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 功能：获取数据库特定用户的数据
	 * @param userid
	 * @return users集合
	 */
public List<User> getUsername(String userid){
		
		Connection conn = JDBCUtil.getConnection();
		List<User> users = new ArrayList<>();
		String sql = "SELECT * FROM customers WHERE id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				String id = rs.getString(1);
				String name = rs.getString(2);
				String authority = rs.getString(3);
				String password = rs.getString(4);
				String address = rs.getString(5);
				String phone = rs.getString(6);
				User user = new User(id,name,authority,password,address,phone);
				
				users.add(user);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(conn, stmt, pstmt, rs);
		}
		
		return users;
	}
	
	/**
	 * 功能：查询所有用户的数据
	 * @return 所有用户的数据集合
	 */
public List<User> getAll(){
		
		Connection conn = JDBCUtil.getConnection();
		List<User> users = new ArrayList<>();
		String sql = "SELECT * FROM customers";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				String id = rs.getString(1);
				String name = rs.getString(2);
				String authority = rs.getString(3);
				String password = rs.getString(4);
				String address = rs.getString(5);
				String phone = rs.getString(6);
				User user = new User(id,name,authority,password,address,phone);
				
				users.add(user);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(conn, stmt, pstmt, rs);
		}
		
		return users;
	}
	
	/**
	 * 功能：根据用户输入信息查看数据
	 * @return 所有用户的数据集合
	 */

public List<User> getAll(User user){
	
	Connection conn = JDBCUtil.getConnection();
	List<User> users = new ArrayList<>();

	//可变字符串
    StringBuffer sb = new StringBuffer();
    sb.append("SELECT ");
    sb.append("id ");
    sb.append(",name ");
    sb.append(",authority ");
    sb.append(",password ");
    sb.append(",address ");
    sb.append(",phone ");
    sb.append("FROM ");
    sb.append("customers ");
    if (user != null) {
    	sb.append("where ");
    }

    //用来存放输入条件是否输入，输入的话，变成true，未输入的话，变成false
    boolean flg = false;

    if (user != null) {
        //如果输入姓名
        if (user.getName() != null && !"".equals(user.getName())) {
        	sb.append("name = ").append("'").append(user.getName()).append("'");
        	flg = true;
        }
    }
        //如果输入权限
    if (user.getAuthority() != null && !"".equals(user.getAuthority())) {
       if (flg) {
            sb.append(" and authority = ").append("'").append(user.getAuthority()).append("'");
        } else {
        	sb.append("authority = ").append("'").append(user.getAuthority()).append("'");
        }
        	flg = true;
    }

     //如果输入住址
    if (user.getAddress() != null && !"".equals(user.getAddress())) {
        if (flg) {
        	sb.append(" and  address like ").append("'%").append(user.getAddress()).append("%'");
        } else {
        	sb.append(" address like ").append("'%").append(user.getAddress()).append("%'");
        }
        flg = true;
    }

      //如果输入电话
    if (user.getPhone() != null && !"".equals(user.getPhone())) {
        if (flg) {
            sb.append(" and phone = ").append("'").append(user.getPhone()).append("'");
        } else {
        	sb.append("phone = ").append("'").append(user.getPhone()).append("'");
        }
        flg = true;
    } 
    
    //拼接的sql语句
    String sql = sb.toString();
	
	try {
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		while(rs.next()){
			String id = rs.getString(1);
			String name = rs.getString(2);
			String authority = rs.getString(3);
			String password = rs.getString(4);
			String address = rs.getString(5);
			String phone = rs.getString(6);
			User user1 = new User(id,name,authority,password,address,phone);
			
			users.add(user1);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
	
	return users;
}

	/**
	 * 根据名字获取单个用户
	 * @param username
	 * @return
	 */
	
public List<User> getNameUsers(String username){
		Connection conn = JDBCUtil.getConnection();
		List<User> users = new ArrayList<>();
		String sql = "SELECT * FROM customers WHERE name=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				String id = rs.getString(1);
				String name = rs.getString(2);
				String authority = rs.getString(3);
				String password = rs.getString(4);
				String address = rs.getString(5);
				String phone = rs.getString(6);
				User user = new User(id,name,authority,password,address,phone);
				
				users.add(user);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(conn, stmt, pstmt, rs);
		}
		
		return users;
	}



/**
 * 根据名字获取单个用户
 * @param username
 * @return
 */

public User getUpdate(String id){
	Connection conn = JDBCUtil.getConnection();
	User user = null;
	String sql = "SELECT * FROM customers WHERE id=?";
	
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		
		while(rs.next()){
			String name = rs.getString(2);
			String authority = rs.getString(3);
			String password = rs.getString(4);
			String address = rs.getString(5);
			String phone = rs.getString(6);
			user = new User(id, name, authority, password, address, phone);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
	
	return user;
}

	/**
	 * 判断账号是否存在数据库中
	 * @param id
	 * @return boolean
	 */
public boolean getExistId(String id){
	Connection conn = JDBCUtil.getConnection();
	String sql = "SELECT id FROM customers WHERE id=?";
	boolean temp = false;//默认用户账号不存在
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		
		while(rs.next()){
			temp = true;
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
	
	return temp;
} 


/**
 * 判断姓名是否存在数据库中
 * @param name
 * @return boolean
 */
public boolean getExistName(String name){
	Connection conn = JDBCUtil.getConnection();
	String sql = "SELECT name FROM customers WHERE name=?";
	boolean temp = false;//默认用户账号不存在
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		rs = pstmt.executeQuery();
	
		while(rs.next()){
			temp = true;
		}
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}

	return temp;
} 




	/**
	 * 功能：注册
	 * @param user
	 * @return 返回注册成功信息
	 */

public String insertInto(User user){
	Connection conn = JDBCUtil.getConnection();
	String sql = "INSERT INTO customers VALUES(?,?,?,?,?,?)";
	String msg ="";
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, user.getId());
		pstmt.setString(2, user.getName());
		pstmt.setString(3, user.getAuthority());
		pstmt.setString(4, user.getPassword());
		pstmt.setString(5, user.getAddress());
		pstmt.setString(6, user.getPhone());
		
		int line = pstmt.executeUpdate();
		
		if(line != 0){
			msg="恭喜你，注册成功！";
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
	
	return msg;
	
	}


/**
 * 删除特定id的用户
 * @param id
 */


public void deleteUser(String id){
	
	Connection conn = JDBCUtil.getConnection();
	String sql = "DELETE FROM customers WHERE id=?";
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,id);
		pstmt.executeUpdate();		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
	
	}

/**
 * 更新数据库信息字段
 * @param user
 */
public void updateUser(User user) {

	Connection conn = JDBCUtil.getConnection();
	String sql = "UPDATE customers SET name = ?,authority=?,password=?,address=?"
			+ ",phone=? WHERE id=?";
	try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,user.getName());
		pstmt.setString(2,user.getAuthority());
		pstmt.setString(3,user.getPassword());
		pstmt.setString(4,user.getAddress());
		pstmt.setString(5,user.getPhone());	
		pstmt.setString(6,user.getId());	
		pstmt.executeUpdate();		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JDBCUtil.close(conn, stmt, pstmt, rs);
	}
}

}
