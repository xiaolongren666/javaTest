package com.xlr.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xlr.model.User;
import com.xlr.util.JDBCUtil;



/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String username = request.getParameter("username");
		String authority = request.getParameter("authority");
		String password = request.getParameter("password");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		JDBCUtil db = new JDBCUtil();
		//判断是否存在账户
		boolean tempId = db.getExistId(id);
		String msg = null;
		//若账号不存在
		if(tempId == true){
			request.setAttribute("id", id);
			request.setAttribute("username", username);
			request.setAttribute("authority", authority);
			request.setAttribute("password", password);
			request.setAttribute("address", address);
			request.setAttribute("phone", phone);
			msg = "您输入的账号已经存在，请再次输入其他账号！";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		}
		
		//判断是否存在姓名
		boolean tempName = db.getExistName(username);
		//若姓名不存在
		if(tempName == true){
			request.setAttribute("id", id);
			request.setAttribute("username", username);
			request.setAttribute("authority", authority);
			request.setAttribute("password", password);
			request.setAttribute("address", address);
			request.setAttribute("phone", phone);
			msg = "您输入姓名已存在，再次输入其他姓名";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		}
		
		
		//在账户和姓名不存在的前提下进行插入操作
		User user = new User(id,username,authority,password,address,phone);
		msg = db.insertInto(user);
		response.setCharacterEncoding("UTF-8");
		response.getWriter().print("<script>alert("+ msg +");</script>");
		response.sendRedirect("CheckServlet");
		return;
		
	}

}
