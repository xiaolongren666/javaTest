package com.xlr.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.xlr.model.User;
import com.xlr.util.JDBCUtil;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static int count;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		String password=request.getParameter("password");
		String flag = request.getParameter("flag");
		JDBCUtil db = new JDBCUtil();
		List<User> users= db.getUsername(id);
		
		
		//判断是否是管理员或普通用户
		for(User user: users){
			
			
			if(id.equals(user.getId())){
				if(password.equals(user.getPassword())){
					
				}else{
					String msg="输入密码有误，请您再次输入正确密码！";
					request.setAttribute("msg", msg);
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
			}
			HttpSession session =request.getSession();
			session.setAttribute("user", user);
		
			
			
			
			if("0".equals(user.getAuthority())){
				count++;
				request.setAttribute("count",count);
				request.getRequestDispatcher("audience.jsp").forward(request, response);
				return;
			}else if("1".equals(user.getAuthority())){
				count++;
				request.setAttribute("count",count);
				request.getRequestDispatcher("admin.jsp").forward(request, response);
				return;
				
			}
		}
		
		//账号输入错误，跳转页面
		String msg="输入账号有误，请您再次输入正确账号！";
		request.setAttribute("msg", msg);
		request.getRequestDispatcher("login.jsp").forward(request, response);
		//response.sendRedirect("login.jsp");		
		
		
//			doGet(request, response);
	}

}
