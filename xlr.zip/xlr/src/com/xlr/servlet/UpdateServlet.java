package com.xlr.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xlr.model.User;
import com.xlr.util.JDBCUtil;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String username = request.getParameter("username");
		String authority = request.getParameter("authority");
		String password = request.getParameter("password");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String flag = request.getParameter("flag");
		String msg="";
		JDBCUtil db = new JDBCUtil();
		if("experience".equals(flag)){
			//获取本用户的所有数据
			User user = new User();
			user = db.getUpdate(id);
			//传递此用户的数据
			request.setAttribute("user", user);
			request.getRequestDispatcher("update.jsp").forward(request, response);
			return;
		}
		if("update".equals(flag)){

			//判断是否存在姓名
			boolean tempName = db.getExistName(username);
			//若姓名不存在
			if(tempName == true){
				User user = new User(id, username, authority, password, address, phone);
				msg = "您输入姓名已存在，再次输入其他姓名";
				request.setAttribute("msg", msg);
				request.setAttribute("user", user);
				request.getRequestDispatcher("update.jsp").forward(request, response);
				return;
			}
			User user = new User(id, username, authority, password, address, phone);
			//条件满足更新记录
			db.updateUser(user);
			response.sendRedirect("CheckServlet");
			return;
		}
	}

}
