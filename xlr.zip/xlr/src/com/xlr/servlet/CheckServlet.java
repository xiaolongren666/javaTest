package com.xlr.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xlr.model.User;
import com.xlr.util.JDBCUtil;

/**
 * Servlet implementation class CheckServlet
 */
@WebServlet("/CheckServlet")
public class CheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//设置中文传送过来的字符集编码
		request.setCharacterEncoding("UTF-8");
		//获取数据库连接
		JDBCUtil db = new JDBCUtil();
		List<User> users = new ArrayList<>();
		//获取查询页传送过来的数据
		String username = request.getParameter("username");
		String authority = request.getParameter("authority");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		if((!"".equals(username) && username != null)
			|| (!"".equals(authority) && authority != null)
			|| (!"".equals(address) && address != null)
			|| (!"".equals(phone) && phone != null)
				){
			User user = new User("",username,authority,"",address,phone);
			users = db.getAll(user);
			request.setAttribute("users", users);
			request.getRequestDispatcher("check.jsp").forward(request, response);
			return;
		}
		
		
		
	
		//查询所有数据
		users = db.getAll();
		request.setAttribute("users", users);
		request.getRequestDispatcher("check.jsp").forward(request, response);
		

	}

}
