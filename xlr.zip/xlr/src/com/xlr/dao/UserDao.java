/**
 * 
 */
package com.xlr.dao;

/*
*@Author:小龙人
*@File Name:UserDao.java
*@Created Time:上午10:04:41
*@Introduce Function:TODO
*/
public class UserDao {

}
