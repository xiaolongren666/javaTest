/**
 * 
 */
package com.xlr.model;

/*
*@Author:小龙人
*@File Name:Product.java
*@Created Time:下午9:05:35
*@Introduce Function:TODO
*/
public class Product {
	private String id;//编号
	private String name;//产品名
	private String price;//产品价格
	private String num;//产品数量
	
	/**
	 * 
	 */
	public Product(String id,String name,String price,String num) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.num = num;
	}
	
	/**
	 * setter()和getter()方法
	 * @return
	 */
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
}
